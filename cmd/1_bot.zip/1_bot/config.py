BOT_TOKEN = ""

DB_NAME = "InternetMagazin.db"
